global nr
if nr == 10
    nr = 0;
else
    nr = nr + 1;
end