# matlabVoiceRec
Matlab voice proyect

Los archivos desde set0 hasta set10 son las grabaciones de voz base.

En **datastetProyecto.m** se encuntra el código principal, falta separarlo por funciones
